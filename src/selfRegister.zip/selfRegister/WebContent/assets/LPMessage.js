/*!
 * Built by LeasePlan AU
 * version: v1.0.0
 * Author: Wei Tao
 * Date: Aug 2017
 */

sap.ui.define([], function () {
    "use strict";

    var LPMessage = function () {
       this._callLeasePlan = "LeasePlan Online is temporarily unavailable, please try again later or call 132 572.";
       this._isSucess = false;
    };
    
    /**
     * Returns 
     * @returns {object}
     */
    LPMessage.prototype.loadSystemMessage = function () {
    	(!this._systemMessage) && (function(){
    		this._systemMessage = sap.ui.xmlfragment("com.lp.selfRegister.fragments.SystemMessage", this);
    		   this._initDom();
    	   	 //  this._setDomVisiable();
	    	}).call(this);
    	return this._systemMessage;
    };
    
    LPMessage.prototype.callLeasePlan = function() { 
    	return  this._callLeasePlan;
    };   
    
    LPMessage.prototype.gotoPortal = function(){
    	this._systemMessage.attachAfterClose((function() {
    		this._systemMessage.destroy();
    	
    	  window.location.replace("/irj/portal");	
		}).bind(this));
		this._systemMessage.close();
    };
    
    LPMessage.prototype.setMessage  = function(message){
    	this._customerMessage.setText(message);
    };
    
    // set message type true is for success message , false is for failed /error message  
    LPMessage.prototype.setMessageType  = function(bType){
    	  this._isSucess = bType;
    	  this._setDomVisiable();
    };
    
    LPMessage.prototype._initDom = function(){
		 this._iconFail = sap.ui.getCore().byId('lpSystemMessage_iconFail');
		 this._goPortalOnline = sap.ui.getCore().byId('lpSystemMessage_goPortalOnline');
		 this._customerMessage = sap.ui.getCore().byId('lpSystemMessage_systemMessage');
		 this._iconSuccess = sap.ui.getCore().byId('lpSystemMessage_iconSuccess');
    };
    
    LPMessage.prototype._setDomVisiable = function(){
    	this._iconFail.setVisible(!this._isSucess);
    	this._iconSuccess.setVisible(this._isSucess)
 		this._goPortalOnline.setVisible(true);
    };
    
    /**
     * @param {(sap.ui.core.Control,String,Boolean)}.
     * @return {object} oControl as Pop up
     */
    LPMessage.prototype.quickhelp = function(oControl, sText, bCustomize) {
    	// create the RichTooltip control
    	var oRichTooltip = new sap.ui.commons.RichTooltip({
    		text : sText,
    		title: "Quick Help",
    		imageSrc : "../../selfRegister/images/Tip.gif"
    	});
    	//Change position and durations if required
    	if (bCustomize) {
    		oRichTooltip.setMyPosition("begin top");
    		oRichTooltip.setAtPosition("end top");
    		oRichTooltip.setOpenDuration(300);
    		oRichTooltip.setCloseDuration(300);
    	}
    	// add it to the control
    	oControl.setTooltip(oRichTooltip);
    	// return the control itself (makes this function a decorator function)
    	return oControl;
    };
    
    return LPMessage;
});