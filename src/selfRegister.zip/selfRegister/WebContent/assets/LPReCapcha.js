/*!
 * Built by LeasePlan AU
 * version: v1.0.0
 * Author: Wei Tao
 * Date: NOV 2017
 */

jQuery.sap.declare("assets.LPReCapcha");

/**
 * call back end service to validate the ticket if available  
 * @param String  - issued by google as ticket
 */
function reCapchaCallback(token) {
	// call server side validation 
	var tokenData = {
			"googleRecaptchaToken" : token 
	}
 	callPortalService("validateRecaptcha",tokenData,validateRecaptchaCallback,this);
};

/**
 * Returns  JSON response data from portal service 
 * @param  sService,oUserData,oCallback,oCallbackObject 
 * @returns success callback with loading data / error if failed will call back with loading failed  
*/
function callPortalService (sService,oUserData,oCallback,oCallbackObject) {
	var host ="";
	var sURL = host + "/portalService/validateRecaptcha", 
		oAjax = {
			method      : "POST",
			contentType : "application/json",
			dataType    : "json",
			data:    JSON.stringify(oUserData)  
		};

		$.ajax(sURL, oAjax).done(function(responseData) {
			oCallback.call (oCallbackObject,responseData,sService);
		}).fail(function(XMLHttpRequest, textStatus) {
			oCallback.call (oCallbackObject , {message : textStatus, statusCode : XMLHttpRequest.status, statusText : XMLHttpRequest.statusText, responseText : XMLHttpRequest.responseText},"failed");
		});
};

/**
 * handler of call back for web service 
 * @param {(data:JSONobject, stage:String)} oControl 
 */
function validateRecaptchaCallback(data,stage) {
    if(stage ==="validateRecaptcha" ){
    	if (data.googleRecaptchaSuccess !=="false") {
    		// process user's initial registration as pass the recaptcha validation from google .
    		sap.ui.controller("com.lp.selfRegister.controller.initialReg.InitialRegister").validateRecaptchaCallback(sap.ui.getCore().AppContext.context);
    	}else {
    		// must be attacked as google thinks so.
            console.log("The data request has been block as can't be validated by google recaptcha token validation -- " +  JSON.stringify(data));
    	}
    }else{
    	 ///system error as web service down
    	 console.log("There are technical issues occured with message are " +  JSON.stringify(data));
    }
     
};
