/*!
 * Built by LeasePlan AU
 * version: v1.0.0
 * Author: Wei Tao
 * Date: Aug 2017
 */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/lp/selfRegister/assets/PortalService",
	"com/lp/selfRegister/assets/Validator",
	"com/lp/selfRegister/assets/LPMessage",
	"com/lp/selfRegister/assets/LPPopover",
	"com/lp/selfRegister/model/SelfRegisterModels",
	"sap/ui/model/SimpleType",
	"sap/ui/model/ValidateException"
	
], function(Controller,Webservice,Validator,LPMessage,LPPopover,SelfRegisterModels,SimpleType,ValidateException) {
	"use strict";
	return Controller.extend("com.lp.selfRegister.controller.completeReg.EnterCustNum", {
		
		onInit: function() {
			var oComponent = this.getOwnerComponent();
    		this._router = oComponent.getRouter();
    		this._router.getRoute("EnterCustNum").attachPatternMatched(this._routePatternMatched, this);
    		this._selfRegisterModels = new SelfRegisterModels();
    		this._oModel = this._selfRegisterModels.createCompleteRegModel();
    		// binding elements value in xml template to completeRegModel of as one of model in selfRegisterModels
    		this.getView().setModel(this._oModel, "completeRegModel").bindElement("/").setBindingContext(new sap.ui.model.Context(this._oModel, "/"));
    		this._lastName =   sap.ui.getCore().getModel("completeRegModel").getProperty("/lastName");
			this._firstName = sap.ui.getCore().getModel("completeRegModel").getProperty("/firstName");
	    	this._emailAddress=  sap.ui.getCore().getModel("completeRegModel").getProperty("/emailAddress");
	    	this._oModel.oData.firstName = this._firstName;
			this._oModel.oData.lastName = this._lastName;
			this._oModel.oData.emailAddress = this._emailAddress;
		    this._customerNumber  = this.byId("customerNumber");
		    this._startDisBtn = this.byId("startDisBtn");
		    this._startBtn = this.byId("startBtn");
		    this._cusNumTxt = this.byId("customerTxt");
		    this._nonCusNumTxt  = this.byId("nonCustomerNumberTxt");
		    this._customerNumberMsg = this.byId("customerNumberMsg");
		    this._cusNumTxt2 = this.byId("customerTxt2");
		    this._changeLink = this.byId("changeLink");
		    this._lpLinkForm = this.byId("lpLinkForm");
		    this._lpCustomerTxtForm = this.byId("lpCustomerTxtForm");
		    this._lpCustomerMsgForm = this.byId("lpCustomerMsgForm");
			
    		sap.ui.getCore().attachValidationError(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("Error");
				}
			});
			sap.ui.getCore().attachValidationSuccess(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("None");
				}
			});
			
			var JSONObject = {
					"emailAddress": this._emailAddress,
					"customerNumber": ""
				};
			/// get customer Number as per customer email address  
			this._getWebService().callPortalService("getCustomerNum",JSONObject,this._renderCustomerDescriptionPage,this);
		},

		NavToPortal: function(){
			window.location.replace("/irj/portal");	
		},

		_routePatternMatched: function(oEvent) {
			this._lastName =   sap.ui.getCore().getModel("completeRegModel").getProperty("/lastName");
			this._firstName = sap.ui.getCore().getModel("completeRegModel").getProperty("/firstName");
	    	this._emailAddress=  sap.ui.getCore().getModel("completeRegModel").getProperty("/emailAddress");
	    	this._oModel.oData.firstName = this._firstName;
			this._oModel.oData.lastName = this._lastName;
			this._oModel.oData.emailAddress = this._emailAddress;
		},
	    
	    checkCustomer: function() {
	        var customerNumber = this.byId("customerNumber");
			this._getValidator().validate(customerNumber);
			if (customerNumber.getValueState() === "Error" || customerNumber.getValue() ==="") {
				//customerNumber.fireSuggest();
				customerNumber.focus();
			}else{
				var viewData = this.getView().oModels.completeRegModel.oData,
				    JSONObject = {
						"emailAddress": this._emailAddress,
						"customerNumber": viewData.customerNumber
					};
				 this._getWebService().callPortalService("verifyCustNum",JSONObject,this._pageNavigation,this);
			}
		},
	  	
	   navigateToDetail: function() {
		    var JSONObject = {
				"emailAddress": this._emailAddress,
				"customerNumber": this.getView().oModels.completeRegModel.oData.customerNumber
			};
		 this._getWebService().callPortalService("verifyCustNum",JSONObject,this._pageNavigation,this);
			
		},
		
	   _renderCustomerDescriptionPage : function(data,stage) {
		ga('send', 'pageview','customerNumberPage');
		this._customerNumber.setValueState('None');
	   	 if (stage==="getCustomerNum") {
	   		 
	   		if (data.returnCRM ==="true"){
	   			if(data.errCode  === "000" ||data.errCode ==="004"||data.errCode  === "003"){ 
	   				this.getView().oModels.completeRegModel.oData.customerNumber = data.customerNumber;
					this._customerNumber.setVisible(false);
					$('<span class="lp_companyName">'+ data.customerDescLong +'.</span>').insertAfter("#lpCustomerTxt1");
					this._changeLink.setVisible(true);
					this._changeLink.setText("click here.");
					this._startBtn.setVisible(false);
					this._startDisBtn.setVisible(true);
			
				}else{
					this._lpCustomerTxtForm.setVisible(false);
					this._lpLinkForm.setVisible(false);
					this._cusNumTxt.setVisible(true).setText("We need more information to link you to the correct employer.");
					this._cusNumTxt2.setVisible(true).setText("Please enter your customer number.");
					this._customerNumber.setVisible(true).setValue(data.customerNumber);
					this._customerNumber.setValueState('Error').setValueStateText('Invalid Customer Number. Please contact your internal employee benefits manager.').focus();
					this._customerNumberMsg.setVisible(true);
					this._changeLink.setVisible(false);
					this._startBtn.setVisible(true);
					this._startDisBtn.setVisible(false);
				}
	   			
	   			
	   		} else {
	   				if ( data.customerNumber !== "") {
	        		this.getView().oModels.completeRegModel.oData.customerNumber = data.customerNumber;
					this._customerNumber.setVisible(false);
					$('<span class="lp_companyName">'+ data.customerDescLong +'.</span>').insertAfter("#lpCustomerTxt1");
					this._changeLink.setVisible(true);
					this._changeLink.setText("click here.");
					this._startBtn.setVisible(false);
					this._startDisBtn.setVisible(true);
				
				
				} else {
					
					
					this._lpCustomerTxtForm.setVisible(false);
					this._lpLinkForm.setVisible(false);
					this._cusNumTxt.setVisible(true).setText("We need more information to link you to the correct employer.");
					this._cusNumTxt2.setVisible(true).setText("Please enter your customer number.");
					this._customerNumber.setVisible(true);
					this._customerNumberMsg.setVisible(true);
					this._changeLink.setVisible(false);
					this._startBtn.setVisible(true);
					this._startDisBtn.setVisible(false);
					
				}
	   				
	   		}
	   	
		
	   	}else{
				   ///system error as web service down
	   		    $(".lpCompleteRegister").hide();
			   	 (function(){
					 this._getLPMessage().loadSystemMessage().open();
					 this._getLPMessage().setMessageType(false);
					 this._getLPMessage().setMessage(this._getLPMessage().callLeasePlan());
				 }).call(this);
		
			}
		},
		
		_pageNavigation: function(data,stage) {
			this._getLPPopover().destroyPopover();
		    if (stage==="verifyCustNum") {
               sap.ui.getCore().setModel(this._oModel, "completeRegModel"); // application level  model setting;
					if(data.errCode  === "000"){ 
						this._oModel.oData.googleAPI = data.googleAPI;
						this._oModel.oData.mandatory = data.mandatory;
						this._router.getTargets().display("CompleteRegister");
					}else if (data.errCode ==="004"){
						this._oModel.oData.duplicate ="true";
						this._oModel.oData.customerData = data.customerData;
						this._oModel.oData.googleAPI = data.googleAPI;
						this._oModel.oData.mandatory = data.mandatory;
						this._router.getTargets().display("CompleteRegister");
					}else if  (data.errCode  === "003" ) {  //work email process 
						this._router.getTargets().display("WorkEmail");
					}else if (data.errCode  === "002" ) {
						//display error message for wrong customer number	
						if (this._customerNumber && this._customerNumber.getVisible()){
							this._customerNumber.setValueState('Error').setValueStateText('Invalid Customer Number. Please contact your internal employee benefits manager.').focus();
							//this._customerNumber.fireSuggest();	
						};
					}else if (data.errCode ==="001" || data.errCode ==="005" || data.errCode ==="006"){ 
					   //001 This email may not proceed with registry as it is already registered
					   //005 Error during BP createion call leaseplan 
					   (function(){
						   		this._getLPMessage().loadSystemMessage().open();
						   	    this._getLPMessage().setMessageType(false);
							   this._getLPMessage().setMessage(data.errReason);
						 }).call(this);
					}else{
						  (function(){
						   		this._getLPMessage().loadSystemMessage().open();
						   	    this._getLPMessage().setMessageType(false);
							   this._getLPMessage().setMessage(data.errReason);
						 }).call(this);
						
					}
				
			}else {
				   ///system error as web service down
				$(".lpCompleteRegister").hide();
				 (function(){
					 this._getLPMessage().loadSystemMessage().open();
					 this._getLPMessage().setMessageType(false);
					 this._getLPMessage().setMessage(this._getLPMessage().callLeasePlan());
				 }).call(this);
			}
		},

		navToenterCust: function() {
	
			this._lpCustomerTxtForm.setVisible(false);
		
			this._lpLinkForm.setVisible(false);
			//this._lpCustomerMsgForm.setVisible(true);
			this._cusNumTxt.setVisible(true).setText("We need more information to link you to the correct employer.");
		   
			this._cusNumTxt2.setVisible(true).setText("Please enter your customer number.");
			this._customerNumber.setVisible(true);
		    this._customerNumberMsg.setVisible(true);
			this._changeLink.setVisible(false);
			//this._customerCompanyName.setVisible(false);
			this._startBtn.setVisible(true);
			this._startDisBtn.setVisible(false);
	
		},
		
		onExit: function() {
			 this._getLPPopover().destroyPopover();
		},

		getInfo: function(evt) {
			 this._getLPPopover().loadPopover();
			 this._getLPPopover().setMessage("Your Customer Number enables us to identify you and your company so that you can access all of the discounts available.");
			 var oInput = evt.getSource();
				jQuery.sap.delayedCall(0, this, function() {
					 this._getLPPopover().getPopover().openBy(oInput);
				});
		},
		
		/**
		* Construct portal service instance 
		* @private
		* @return {object} 
		*/
        _getWebService : function() {
            if  (!this._webservice){
            	 this._webservice = new Webservice();
            }
            return this._webservice;
        },
        
    	/**
		* Construct form Validator instance 
		* @private
		* @return {object} 
		*/
        _getValidator : function() {
            if  (!this._validator){
            	   this._validator  = new Validator();
            }
            return this._validator;

        },

		/**
		* Construct form LPMessage instance 
		* @private
		* @return {object} 
		*/
        _getLPMessage : function() {
            if  (!this._LPMessage){
            	   this._LPMessage  = new LPMessage();
            }
            return this._LPMessage;
        },
        
        /**
		* Construct form LPPopover instance 
		* @private
		* @return {object} 
		*/
        _getLPPopover : function() {
            if  (!this._LPPopover){
            	   this._LPPopover  = new LPPopover();
            }
            return this._LPPopover;
        },
        
    	/**
		* validate customer Number 
		*/
        typeInput: SimpleType.extend("customerNumber",{
			formatValue: function(oValue) {
				return oValue;
			},
			parseValue: function(oValue) {
				return oValue;
			},
			validateValue: function(oValue) {
				if (!oValue) {
					throw new ValidateException("Invalid Customer Number!");
				}
				if (oValue.length >10 ){
					throw new ValidateException("'" + oValue + "' exceeds maximum length allowed");
				}
				
			}
		})

	});
});