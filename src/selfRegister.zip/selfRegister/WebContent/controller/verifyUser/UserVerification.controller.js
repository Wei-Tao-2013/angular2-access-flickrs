/*!
 * Built by LeasePlan AU
 * version: v1.0.0
 * Author: Wei Tao
 * Date: Aug 2017
 */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/lp/selfRegister/assets/PortalService",
	"com/lp/selfRegister/assets/LPMessage",
	"com/lp/selfRegister/model/SelfRegisterModels",
	"sap/ui/commons/TextView",
	"sap/ui/commons/Image"
], function(Controller,Webservice,LPMessage,SelfRegisterModels,TextView,Image) {

	"use strict";

	return Controller.extend("com.lp.selfRegister.controller.verifyUser.UserVerification", {
			
		/**
		* Called when a controller is instantiated and its View controls (if available) are already created.
		* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		* @memberOf verifyuser.UserVerification
		*/

		onInit: function() {
			var oComponent = this.getOwnerComponent();
				this._router = oComponent.getRouter();
				this._selfRegisterModels = new SelfRegisterModels();
				this._oModel = this._selfRegisterModels.createVerifyCodeModel();
				this._router.getRoute("verifyUser").attachPatternMatched(this._routePatternMatched, this);
		},
		
		_routePatternMatched: function (oEvent) {
			var queryArray = oEvent.mParameters.arguments['?query'];
			this._lastName =   queryArray.l;
			this._firstName = queryArray.f;
			this._emailAddress=  queryArray.e;
			this._verifyCode = queryArray.v;
			this._oModel.oData.firstName = this._firstName;
			this._oModel.oData.lastName = this._lastName;
			this._oModel.oData.emailAddress = this._emailAddress;
			this._oModel.oData.verifyCode = this._verifyCode;
				
			var JSONObject = {
				"emailAddress": this._emailAddress,
				"firstName": this._firstName,
				"lastName" : this._lastName,
				"refNumber" : this._verifyCode,
				"verIndicator" : "true"
			};

			/// verify intiail user with verification code that generated from CRM
			this._getWebService().callPortalService("verifyInitialUser",JSONObject,this._navigateView,this);
		},

		// if pass verification by code will set token in session then automatically redirect to enter customer number page 
		//other wise will display verification code failed page and provide re-send code function
		_navigateView: function(data,stage) {
			ga('send', 'pageview','verifyInitialUserProcess');
			if (stage==="verifyInitialUser") {
				data.returnCRM ==="true" ? (function(){
					// set token in session  
					var JSONObject = {
							"emailAddress": this._emailAddress,
						};
					this._getWebService().callPortalService("registerSession",JSONObject,this._navigateEnterCustNum,this);
				}).call(this) : (function(){
					this._getVerifyCodeMessage().open();
					//sap.ui.getCore().byId('customerMessage').setText("Verification link is invalid. Please resend the verification link to your email to try again. If you continue to experience this error, please contact Customer Service on 132 572");
					sap.ui.getCore().byId('customerMessage').setText("This verification link has expired, to resend a new link, please enter your email and password here: www.leaseplan.com.au/lp-online.");
					sap.ui.getCore().byId('iconImg').setVisible(false);
				}).call(this);
				
			}else {
				 ///system error as web service down
				 (function() {
 					this._getLPMessage().loadSystemMessage().open();
 					this._getLPMessage().setMessageType(false);
 					this._getLPMessage().setMessage(this._getLPMessage().callLeasePlan());
				 }).call(this);
			}
		},
		
	   _getVerifyCodeMessage:function(){
			 if (!this._verifyCodeMessage) {
					this._verifyCodeMessage = sap.ui.xmlfragment("com.lp.selfRegister.fragments.verifyUser.VerifyCodeMessage", this);
				}
			 return this._verifyCodeMessage;
		},
	
       	///navigate to complete register stage
       _navigateEnterCustNum: function(data,stage){
        if (stage==="registerSession") {
           (data.returnUME ==="true") ? (function(){
        	  this._router.navTo("TokenValidate", { query: {e : this._emailAddress,f: this._firstName,l: this._lastName}},true );
          }).call(this) : (function(){
        	    // something wrong with session setting on server.
        	    this._getLPMessage().loadSystemMessage().open();
        		this._getLPMessage().setMessageType(false);
				this._getLPMessage().setMessage("There is session issues caused by "+ data.errReason + " please try it later on.");
          }).call(this);
      
        }else{
			 ///system error as web service is down
			 (function(){
				 this._getLPMessage().loadSystemMessage().open();
				 this._getLPMessage().setMessageType(false);
				 this._getLPMessage().setMessage(this._getLPMessage().callLeasePlan());
			 }).call(this);
			
		}
	   },
	
		goToPortal : function(){
			this._verifyCodeMessage && (function(){
					this._verifyCodeMessage.attachAfterClose( (function() {
						this._verifyCodeMessage.destroy();
						window.location.replace("/irj/portal");	
				}).bind(this));
				this._verifyCodeMessage.close();
			}).call(this);
		},
		
		// re send verification code via email through CRM
		sendVerLink : function()
		{
			sap.ui.getCore().byId('resendCodeBtn').setEnabled(false);
			var JSONObject = {
					"emailAddress": this._emailAddress,
					"refNumber": "",
					"firstName" : this._firstName,
					"lastName" : this._lastName,
					"verIndicator" : "false"
				};
			
			//call web service to send verification code
			this._getWebService().callPortalService("verifyInitialUser",JSONObject,this._displayConfirmPage,this);
		},
		
		// 
		_displayConfirmPage: function(data,stage){
			if (stage==="verifyInitialUser") {
				this._getVerifyCodeMessage().open();
				if(data.returnCRM === "true"){
					sap.ui.getCore().byId('customerMessage').setText("Almost there! We have sent you an email to verify your account. Please click on the link in the email to complete your registration.");
					sap.ui.getCore().byId('iconImg').setVisible(true);
					sap.ui.getCore().byId('resendCodeBtn').setVisible(false);
					sap.ui.getCore().byId('goPortalOnline').setVisible(true);
				} else {
					sap.ui.getCore().byId('customerMessage').setText("Whoops! Something went wrong. Please try again or contact LeasePlan on 132 572 if the issue continues.");
					sap.ui.getCore().byId('resendCodeBtn').setVisible(true).setEnabled(true);
					sap.ui.getCore().byId('goPortalOnline').setVisible(true);
				}
			}else {
				// something wrong with web service  
				  this._verifyCodeMessage && (function(){
					  this._verifyCodeMessage.close();
					  this._verifyCodeMessage.destroy();
				  }).call(this);
				  this._getLPMessage().loadSystemMessage().open();
					 this._getLPMessage().setMessageType(false);
			      this._getLPMessage().setMessage(this._getLPMessage().callLeasePlan());
			}
		},
	
		/**
		* Construct portal service instance 
		* @private
		* @return {object} 
		*/
		_getWebService : function() {
			if  (!this._webservice){
					this._webservice = new Webservice();
			}
			return this._webservice;
		},
		
		/**
		* Construct form LPMessage instance 
		* @private
		* @return {object} 
		*/
        _getLPMessage : function() {
            if  (!this._LPMessage){
            	   this._LPMessage  = new LPMessage();
            }
            return this._LPMessage;
        }
     
	});
});