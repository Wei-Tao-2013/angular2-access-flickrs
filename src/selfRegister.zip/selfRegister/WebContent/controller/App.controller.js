/*!
 * built by LeasePlan AU
 * version: v1.0.0
 * Author: wei tao
 */

sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("com.lp.selfRegister.controller.App", {

	});

});