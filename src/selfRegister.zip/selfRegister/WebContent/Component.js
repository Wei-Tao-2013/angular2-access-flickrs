/*!
 * Built by LeasePlan AU
 * version: v1.0.0
 * Author: Wei Tao
 * Date: Aug 2017
 */

(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-19995299-8', 'auto');
  
  // google recaptcha call back
  function onSubmit(token) {
		//alert(token);
		sap.ui.getCore().AppContext.invokeRecaptchaCallback = true;
	   	jQuery.sap.require("com/lp/selfRegister/assets/LPReCapcha");
	   	reCapchaCallback(token);
   };

   
  sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/lp/selfRegister/model/SelfRegisterModels"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("com.lp.selfRegister.Component", {
		metadata: {
			manifest: "json"
		},
		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);
    		this._selfRegisterModels = new models();
			this.initializeModels();
			// create the views based on the url/hash
			this.getRouter().initialize();
			var that = this;
			sap.ui.Device.orientation.attachHandler(function(oEvent){
				sap.ui.getCore().getModel("device").refresh(true);
			});
		},
		
	
		initializeModels: function() {
			// set the device model
			//this.setModel(this._selfRegisterModels.createDeviceModel(), "device");
			sap.ui.getCore().setModel(this._selfRegisterModels.createDeviceModel(), "device"); 
			// set the i18n model
			this.setModel(this._selfRegisterModels.createResourceModel(this.getMetadata().getModels().i18n.bundleName), "i18n");
		}
	});
});