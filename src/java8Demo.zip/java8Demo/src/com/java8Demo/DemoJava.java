package com.java8Demo;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * @author taowe
 *
 */
public class DemoJava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("---Start Java8 Test Procces---");
		// creating sample Collection
		List<Integer> myList = new ArrayList<Integer>();
		for (int i = 0; i < 10; i++)
			myList.add(i);

		// traversing using Iterator
		Iterator<Integer> it = myList.iterator();
		while (it.hasNext()) {
			Integer i = it.next();
			System.out.println("Iterator Value::" + i);
		}

		// traversing through forEach method of Iterable with anonymous class
		myList.forEach(new Consumer<Integer>() {
			public void accept(Integer t) {
				System.out.println("forEach anonymous class Value::" + t);
			}
		});

		// traversing with Consumer interface implementation
		MyConsumer action = new MyConsumer();
		myList.forEach(action);
		Runnable r = new Runnable() {
			@Override
			public void run() {
				System.out.println("My Runnable");
			}
		};
		r.run();
		Runnable r1 = () -> {
			System.out.println("My second Runnable");
		};
		r1.run();
		Interface1 i2 = new Interface1() {
			@Override
			public void method1(String str) {
				System.out.println("traditonal approching -->" + str);

			}
		};
		i2.method1("i2");
		Interface1 i1 = (s) -> System.out.println(s);
		i1.method1("abc");
		Interface1.print("kkkk");
		i1.log("kkkk");
		// sequential
		// sequential stream
		Stream<Integer> sequentialStream = myList.stream();
		// parallel stream
		Stream<Integer> parallelStream = myList.parallelStream();
		// using lambda with Stream API, filter example
		Stream<Integer> highNums = parallelStream.filter(p -> p > 1);
		// using lambda in forEach
		highNums.forEach(p -> System.out.println("High Nums parallel=" + p));
		Stream<Integer> highNumsSeq = sequentialStream.filter(p -> p > 1);
		highNumsSeq.forEach(p -> System.out.println("High Nums sequential=" + p));
		System.out.println("is Prime -> " + Interface1.isPrime(17));
		List<String> lines = Arrays.asList("spring", "node", "mkyong");
		List<String> result = lines.stream() // convert list to stream
				.filter(line -> !"mkyong".equals(line)) // we dont like mkyong
				.collect(Collectors.toList()); // collect the output and convert
												// streams to a List
		result.forEach(System.out::print); // output : spring, node
		List<String> lines1 = Arrays.asList("Spring", "node", "mkong"); // covert
																		// input
																		// data
																		// to
																		// list
		List<String> result1 = lines1.stream().filter(line -> !"mkyong".equals(line)).collect(Collectors.toList());
		result1.forEach(System.out::println);
		List<Integer> line2 = Arrays.asList(1, 2, 3);
		// line2.add(5);
		List<Integer> line3 = new ArrayList<Integer>();
		for (int i = 0; i < 10; i++)
			line3.add(i);
		line3.forEach(System.out::println);
		// convert Json input ot list // done
		class MyObj {
			final String name;
			final String pattern;

			public MyObj(String name, String pattern) {
				this.name = name;
				this.pattern = pattern;
			}
		}

		StringBuffer stringBuffer = new StringBuffer(); // dummy source
		stringBuffer.append("{ClientRequest:[" + "{name:a,pattern:high}," + "{name:b,pattern:medium},"
				+ "{name:c,pattern:low}," + "{name:d,pattern:low}," + "{name:e,pattern:high},"
				+ "{name:f,pattern:trusted}," + "{name:g,pattern:trusted}," + "{name:h,pattern:high},"
				+ "{name:i,pattern:medium}," + "{name:j,pattern:trusted}," + "{name:k,pattern:none},"
				+ "{name:l,pattern:high}," + "{name:m,pattern:none}]}");

		// convert by jsonObject

		JSONObject jsonObject = new JSONObject(stringBuffer.toString());
		JSONArray userArray = (JSONArray) jsonObject.get("ClientRequest");

		List<MyObj> list = new ArrayList<MyObj>();
		userArray.forEach(item -> {
			JSONObject o = (JSONObject) item;
			list.add(new MyObj(o.getString("name"), o.getString("pattern")));
		});

		Predicate<MyObj> predicateString = s -> s.pattern.equals("low");// s.equals("Hello");

		// output list

		List<MyObj> result2 = list.stream().filter(item -> predicateString.test(item)).collect(Collectors.toList());

		HashSet<String> hashsetobj = new HashSet<String>();
		hashsetobj.add("Alive is awesome");
		hashsetobj.add("Love yourself");
		System.out.println("HashSet object output :" + hashsetobj);

		Map hashmapobj = new HashMap();
		hashmapobj.put("Alive is ", "awesome");
		hashmapobj.put("Love", "yourself");
		System.out.println("HashMap object output :" + hashmapobj);

		// Collection l = new LinkedList();

		// print out list
		result2.forEach(i -> System.out.println(i.name + "--->" + i.pattern));

		java.util.function.BiFunction<Integer, Integer, Integer> add = (a, b) -> a + b;
		
		// add(3,4);

		System.out.println("AwesomeClass ---> " + AwesomeClass.invertTheNumber());
		System.out.println("AwesomeClass ---> " + AwesomeClass.changeTheNumber(a -> a + 3));
		DecimalFormat myFormatter = new DecimalFormat("#.##");
		String output = myFormatter.format(1212121.12121);
		System.out.println(output);
		String source = "sdfsfdsfsd121212dsfmd,12121212,10.00;sdfsfdsfsd121212dsfmd,12121212,10.00;sdfsfdsfsd121212dsfmd,12121212,10.00;sdfsfdsfsd121212dsfmd,12121212,10.00;";
		String[] arrystr = source.split(";");
		List<String> wordList = Arrays.asList(arrystr);
		List<MyObj> listq = new ArrayList<MyObj>();
		wordList.forEach(i -> {
			String[] trans = i.split(",");

		});
		
		
		AwesomeClass.argsFunction(1,2,3,4);

	}

}

// Consumer implementation that can be reused
class MyConsumer implements Consumer<Integer> {
	public void accept(Integer t) {
		System.out.println("Consumer impl Value::" + t);
	}

}

/*
 * 
 * class MyObj { final String name; final String pattern;
 * 
 * public MyObj(String name, String pattern) { this.name = name; this.pattern =
 * pattern; } }
 */

class AwesomeClass {

	public static Integer compute1(Function<Integer, Integer> function, Integer value) {
		return function.apply(value);
	}

	private static Integer invert(Integer value) {
		return null;
	}

	public static Integer invertTheNumber() {

		Integer toInvert = 5;
		// Function<String, Integer> invertFunction = AwesomeClass::invert;
		// return compute(invertFunction, toInvert);
		return compute1((a) -> -a, toInvert);
	}

	public static Integer changeTheNumber(Function<Integer, Integer> func) {
		Integer toChange = 5;
		return compute1(func, toChange);
	}

	public static Integer compute2(Function<Integer, Integer> function, Integer value) {
		return function.apply(value);

	}

	// Function<Integer, Integer> func= new Function<Integer, Integer>();
	
	
	public static void argsFunction(int ...args){
		
	  System.out.println(args);
	  for(int i:args){
		  System.out.println(i);
		  
	  }
	}

}
