package com.java8Demo;

import java.util.List;
import java.util.function.IntPredicate;
import java.util.stream.IntStream;

@FunctionalInterface
public interface Interface1 {
	void method1(String str);
	default void log(String str){
		System.out.println("I1 logging::"+str);
	}
	
	static void print(String str){
		System.out.println("Printing "+str);
	}
	
	static boolean isBigestEvenNumber (List<String> words){
		
	   // words.stream().filter
		return false;
	} 
	
	static boolean isPrime(int number){
		IntPredicate isDivisible = index -> number % index == 0;
		return number > 1 && IntStream.range(2, number).noneMatch(isDivisible);
	}

}
